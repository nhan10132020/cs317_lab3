from observability.Logging.logger import Logger
from observability.Tracing.trace import Tracer
from observability.Metric.metric import Metric
from opentelemetry.sdk.resources import Resource

class Observability:
    def __init__(self,otel_endpoint_url,service_name,format):
        self.resource = Resource.create({
                "service.name": service_name,
        })
        self.otel_endpoint_url = otel_endpoint_url
        self.service_name = service_name
        self.format = format
        
        self.logger = Logger(self.otel_endpoint_url,self.format,self.resource)
        self.trace = Tracer(otel_endpoint_url,self.resource)
        self.metric = Metric(otel_endpoint_url, self.resource)
        
