import logging
import time
from time import perf_counter
from django.utils.deprecation import MiddlewareMixin
from observability.Logging.logger import request_context
from opentelemetry import trace
from opentelemetry.propagate import extract
import traceback

# Acquire a tracer
tracer = trace.get_tracer(__name__)

class DjangoRequestContextMiddleware(MiddlewareMixin):
    """
    Middleware to log request context, trace execution, and measure execution time.
    """

    def process_request(self, request):
        """
        This method is called for each request before the view (and later middleware) is called.
        """
        self.start_time = perf_counter()

        # extract parent context
        traceparent = request.META.get('HTTP_TRACEPARENT')
        if not traceparent:
            traceparent = request.META.get('traceparent')
        ctx = extract({"traceparent": traceparent}) if traceparent else None

        # Start a new trace span
        self.current_span = tracer.start_as_current_span(f"{request.method} {request.path}",context=ctx)
        self.current_span.__enter__()

        # Set request details in context variables
        request_context["method"].set(request.method)
        request_context["path"].set(request.path)
        request_context["client_host"].set(request.META.get('REMOTE_ADDR', None))

    def process_response(self, request, response):
        """
        This method is called for each response after the view (and later middleware) has been called.
        """
        # Calculate execution time
        execution_time = perf_counter() - getattr(self, 'start_time', time.time())

        # Log the execution time with status code
        logging.info(
            f"api - host={request.META.get('REMOTE_ADDR', None)} - path={request.path} - method={request.method} - execution_time_second={execution_time:.2f} status={response.status_code}",
        )

        # Clear context variables after the request
        for key in request_context:
            request_context[key].set(None)

        # End the current trace span
        if hasattr(self, 'current_span'):
            self.current_span.__exit__(None, None, None)

        return response

    def process_exception(self, request, exception):
        """
        Called if the view raises an exception.
        Logs the exception, sets the span status, and ensures the trace span is closed.
        """
        if hasattr(self, 'current_span'):
            # End the span with the exception
            self.current_span.__exit__(type(exception), exception, exception.__traceback__)