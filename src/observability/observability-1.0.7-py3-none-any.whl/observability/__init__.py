from .monitor import Observability
from .middleware.fastAPI import FastAPIRequestContextMiddleware as FastAPIMonitor
from .middleware.djangoAPI import DjangoRequestContextMiddleware as DjangoMonitor
from opentelemetry import trace
from opentelemetry import metrics

def config(config):
    return Observability(config["otel_endpoint_url"], config["service_name"], config["format"])