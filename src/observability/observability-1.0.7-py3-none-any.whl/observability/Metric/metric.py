from opentelemetry import metrics
from opentelemetry.sdk.metrics import MeterProvider
from opentelemetry.sdk.metrics.export import (
    PeriodicExportingMetricReader,
)
from opentelemetry.exporter.otlp.proto.grpc.metric_exporter import OTLPMetricExporter

class Metric:
    def __init__(self,otel_endpoint,resource):
        otlp_exporter = OTLPMetricExporter(endpoint=otel_endpoint, insecure=True)

        metric_reader = PeriodicExportingMetricReader(otlp_exporter)
        provider = MeterProvider(metric_readers=[metric_reader],resource=resource)

        # Sets the global default meter provider
        metrics.set_meter_provider(provider)
