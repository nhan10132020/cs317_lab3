import logging
from opentelemetry.sdk.resources import Resource
from opentelemetry.exporter.otlp.proto.grpc._log_exporter import OTLPLogExporter
from opentelemetry.sdk._logs import LoggerProvider, LoggingHandler 
from opentelemetry.sdk._logs.export import BatchLogRecordProcessor
from opentelemetry._logs import (
    set_logger_provider 
)
import contextvars

# Context variables to store request info
request_context = {
    "method": contextvars.ContextVar("method"),
    "path": contextvars.ContextVar("path"),
    "client_host": contextvars.ContextVar("client_host"),
}
        
class RequestContextFilter(logging.Filter):
    def filter(self, record):
        # Add request context to log record if available
        for key, ctx_var in request_context.items():
            setattr(record, key, ctx_var.get('None'))
        return True
    
class Logger():
    def __init__(self, otel_endpoint_url,format,resource):
        log_level = logging.NOTSET
        logger_provider = LoggerProvider(
            resource=resource
        )
        set_logger_provider(logger_provider)
        
        otlp_log_exporter = OTLPLogExporter(endpoint=otel_endpoint_url)
        logger_provider.add_log_record_processor(BatchLogRecordProcessor(otlp_log_exporter))

        otel_log_handler = LoggingHandler(logger_provider=logger_provider)
        logFormatter = logging.Formatter(format)
        otel_log_handler.setFormatter(logFormatter)
        logging.getLogger().addHandler(otel_log_handler)
        logger = logging.getLogger()
        logger.setLevel(log_level)
        
        # Add filter to logger
        request_context_filter = RequestContextFilter()
        logger.addFilter(request_context_filter)

