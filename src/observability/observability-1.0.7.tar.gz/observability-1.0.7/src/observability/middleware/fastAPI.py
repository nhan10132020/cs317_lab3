import json
import logging
import time
from fastapi import Request
from fastapi.responses import JSONResponse
from time import perf_counter

from fastapi.requests import Request
from starlette.middleware.base import BaseHTTPMiddleware
from observability.Logging.logger import request_context

from opentelemetry import trace
from opentelemetry.propagate import extract
import traceback

# Acquire a tracer
tracer = trace.get_tracer(__name__)

class FastAPIRequestContextMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next):
            headers = dict(request.headers)
            traceparent = headers.get("HTTP_TRACEPARENT")
            
            if not traceparent:
                traceparent = headers.get("traceparent")
            ctx = extract({"traceparent": traceparent}) if traceparent else None
            
            with tracer.start_as_current_span(f"{request.method} {request.url.path}",context=ctx) as span:
                try:
                    # Set request details in context variables
                    request_context["method"].set(request.method)
                    request_context["path"].set(request.url.path)
                    request_context["client_host"].set(request.client.host if request.client else None)

                    # Start timing
                    start_time = perf_counter()
                    
                    # Process request
                    response = await call_next(request)

                    # Calculate execution time
                    execution_time = perf_counter() - start_time
                    # Log the execution time with extra field
                    logging.info(
                        f"api - host={request.client.host} - path={request.url.path} - method={request.method} - execution_time_second={execution_time:.2f} - status={response.status_code}",
                    )
                    
                    # Clear context variables after request
                    for key in request_context:
                        request_context[key].set(None)

                    return response
                except Exception as exc:
                    traceback_str = traceback.format_exc()
                    logging.error(traceback_str)
                    span.set_status(trace.Status(trace.StatusCode.ERROR, str(exc)))
                    
                    return JSONResponse(
                        status_code=500,
                        content={
                            "detail": "Internal Server Error",
                        },
                    )